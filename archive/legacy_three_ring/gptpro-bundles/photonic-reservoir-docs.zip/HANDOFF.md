---
title: MRR RNN Araştırması - Oturum Devri
type: handoff
status: active
created: 2026-08-28
updated: 2026-08-28
---

# MRR RNN Araştırması — Handoff

## Oturum durumu

2026-08-28 oturumu Hasan'ın isteğiyle kapatıldı. Proje aktif fakat beklemededir.
Geri dönüşte bu dosya kanonik başlangıç noktasıdır.

## Amaç ve kapsam

SiN mikro-ringlerle fiziksel olarak savunulabilir recurrent/reservoir computation
geliştirmek. İlk yayın hedefi NARMA-10'dur. Si taşıyıcı/termal fiziği, FDFD solver
iterasyonu ve Tait weight-bank CTRNN bu modelle karıştırılmaz.

## Tamamlananlar

- Enerji-normalize üç-ring TCMT, fiziksel Kerr, direct/coherent readout ve kompleks
  interpolasyonlu delay-feedback tek pakette kuruldu.
- NARMA, leakage-safe ridge, input-only/delayed-input, eşit durumlu ESN, coupling-off,
  memory-reset, single-ring ve Kerr ablationları uygulandı.
- Validation-only iki aşamalı üç-ring ve delay aramaları tamamlandı; test seti yalnız
  aday kilitlendikten sonra değerlendirildi.
- 17 test geçiyor: analitik steady-state, zaman-adımı yakınsaması, determinism,
  delay, NARMA hizası, split ve cloud-gate güvenliği dahil.
- Eski Tidy3D kanıtları SHA-256 manifestine alındı; orijinal dosyalara dokunulmadı.

## Doğrulanmış sonuçlar

- NARMA-3: üç-ring `0.0687`, delayed-input `0.2032`, ESN `0.1040` medyan NMSE.
- NARMA-10 seçilmiş üç-ring-only: `0.4281`; delayed-input `0.3609`, ESN `0.2759`.
- Seçilmiş delay (`1 sembol`, `η=0.8`, `φ=0`) + üç-ring: `0.3502`.
- Aynı delay ile uncoupled/single-ring: `0.3492`; kazanç üç-ring coupling'den değil
  feedback memory'den geliyor.
- Delay adayının delayed-input'a medyan üstünlüğü yalnız `%3`; eşleştirilmiş `%95`
  CI `[-0.0475, 0.0207]`, yani yayın kapısı geçilmedi.
- Fiziksel Kerr açık/kapalı farkı yaklaşık `10⁻⁶` göreli seviyede ve avantaj değil.
- Eski üç-ring statik FDTD: power NMSE `0.154`, power corr `0.980`, fakat global
  kompleks gain sonrası kompleks NMSE `1.180`; sıkı fiziksel kapı başarısız.
- Eski tek-ring transient: corr `0.971`, NMSE `0.202`; `<0.2` kapısını az farkla geçemedi.
- Dinamik üç-ring FDTD benchmarkı yoktur; cloud kapısı kapalıdır.

## Kanonik dosyalar

- [[🏰 300-Projects/Photonic-Reservoir/Photonic-Reservoir|Proje merkezi]]
- [[🏰 300-Projects/Photonic-Reservoir/MODEL-AND-ACCEPTANCE|Model ve kabul protokolü]]
- `src/photonic_reservoir/`, `configs/`, `runs/`, `evidence/`, `tests/`

## Kararlar

- “FDTD-fitted TCMT” hiçbir yerde doğrudan “FDTD benchmarkı” diye adlandırılmayacak.
- Kerr yalnız fiziksel `n₂` ile istatistiksel avantaj verirse katkı olarak sunulacak.
- Mevcut düşük-Q üç-ring-only ve tek-delay hibrit aday için yeni cloud kredisi harcanmayacak.
- NARMA-3 kontrol görevidir; yayın ve FDTD kapısını yalnız tam 10-seed NARMA-10 açabilir.

## Açık riskler

- Mevcut Q/lifetime NARMA-10 belleği için kısa.
- Delay-loop sonucu coupling ablation'ında korunuyor; mevcut halkalar hesaplamaya anlamlı
  ek durum sağlamıyor.
- Fiziksel SiN Kerr kayması mevcut güç/Q aralığında çözünür değil.
- Ren et al. high-Q lineer MRR array makalesinin tam parametre kartı hâlâ eksik.

## Sıradaki tek adım

Ren et al. tam metnini edin; high-Q lineer MRR memory-array/on-chip multi-delay
mimarisini aynı TCMT arayüzünde kur. Yeni aday önce validation-only NARMA-10 kapısını
geçmeli; geçmeden tam yayın koşusu veya Tidy3D cloud doğrulaması başlatma.

## Yeni sohbete başlangıç

> `Photonic-Reservoir/HANDOFF.md`, `Photonic-Reservoir.md`,
> `MODEL-AND-ACCEPTANCE.md` ve `runs/search_delay_narma10.json` dosyalarını oku.
> Mevcut üç-ring ve tek-delay adaylarını yeniden tarama. Sıradaki tek adımı uygula:
> high-Q MRR memory-array/on-chip multi-delay modelini kaynak denklemlerle kur ve
> validation-only NARMA-10 karşılaştırmasını yap.
