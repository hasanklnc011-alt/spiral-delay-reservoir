﻿# benchmark - photonic-reservoir

- Paket amaci: NARMA uretimi, leakage-safe split, ridge readout, baseline'lar, paired bootstrap ve validation-only aramalar.
- Export zamani (UTC): 2026-09-02T13:27:34Z
- Git commit: 789f9fa
- Dosya sayisi: 5

Bu bir SNAPSHOT'tir. Canli depo bu tarihten sonra degismis olabilir.
Bulgularini dosya/satir capasiyla ver ki operator canli agacta dogrulayabilsin.
