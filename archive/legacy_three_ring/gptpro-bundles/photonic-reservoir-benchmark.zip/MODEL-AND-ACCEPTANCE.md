# Model ve Kabul Protokolü

## Ana model

Durumlar enerji-normalize kompleks halka alanlarıdır. `|a_i|²` joule,
`|s_in|²` watt birimindedir. Üç halka karşılıklı nearest-neighbor coupling ile
bağlanır; direct-detection through-port örnekleri lineer ridge readout'a verilir.

Si'ye özgü TPA, FCA, FCD ve termal durumlar SiN modelinde bulunmaz. Delay kontrolü
kompleks çıkış alanının gecikmiş kopyasını girişe ekler. Tait weight-bank CTRNN ve
FDFD fixed-point çalışmaları bu paketin iddia kapsamı dışındadır.

## Zorunlu ablation'lar

- Fiziksel Kerr açık / kapalı.
- Üç-ring / tek-ring.
- Coupling açık / kapalı.
- Persistent state / her sembolde reset.
- Direct-detection / coherent-field.
- Input-only, delayed-input ve eşit boyutlu dijital ESN.

## Yayın kapıları

NARMA-10 için medyan NMSE `<0.30`, delayed-input'a göre en az `%10` iyileşme,
seed'lerin en az `%80`'inde üstünlük ve eşleştirilmiş farkın `%95` bootstrap üst
sınırının sıfırın altında olması gerekir. Kerr avantajı aynı istatistik kuralı ve
en az `%10` iyileşme olmadan iddia edilmez.

Yeni Tidy3D cloud koşuları bu kapı açılmadan başlatılmaz. Statik kompleks spektrum
için normalize hata `<0.2` ve güç korelasyonu `>0.95`; kısa transient için
korelasyon `>0.95` ve NMSE `<0.2` hedeflenir.
