import unittest
from dataclasses import replace

import numpy as np

from photonic_reservoir.config import DriveConfig, FeedbackParams, RingParams, SolverConfig, TopologyParams
from photonic_reservoir.model import encoded_power, linear_s21, simulate


class ModelTests(unittest.TestCase):
    def test_ring_q_and_lifetime_are_consistent(self):
        ring = RingParams()
        self.assertAlmostEqual(1.0 / ring.q_loaded, 1.0 / ring.q_int + 1.0 / ring.q_ext)
        self.assertAlmostEqual(ring.tau_field_s, 2.0 * ring.q_loaded / ring.omega0)

    def test_input_power_is_nonnegative(self):
        drive = DriveConfig()
        self.assertGreaterEqual(encoded_power(0.0, 1.0, drive), drive.minimum_power_w)

    def test_linear_s21_is_finite(self):
        topology = TopologyParams(kerr_enabled=False)
        response = linear_s21(topology, np.linspace(-2e12, 2e12, 101))
        self.assertTrue(np.all(np.isfinite(response)))

    def test_simulation_shapes_and_determinism(self):
        topology = TopologyParams(kerr_enabled=False)
        drive = DriveConfig(n_virtual=4, symbol_time_s=1e-12)
        u = np.linspace(0.0, 0.5, 12)
        first = simulate(u, topology, drive)
        second = simulate(u, topology, drive)
        self.assertEqual(first.features.shape, (12, 4))
        self.assertEqual(first.cavity_energy_j.shape, (12, 4, 3))
        np.testing.assert_allclose(first.features, second.features)

    def test_memory_reset_changes_trajectory(self):
        topology = TopologyParams(kerr_enabled=False)
        u = np.array([0.1, 0.4, 0.2, 0.3])
        persistent = simulate(u, topology, DriveConfig(n_virtual=3))
        reset = simulate(u, topology, DriveConfig(n_virtual=3, reset_each_symbol=True))
        self.assertFalse(np.allclose(persistent.features, reset.features, rtol=1e-10, atol=1e-14))

    def test_delay_feedback_runs(self):
        topology = TopologyParams(kerr_enabled=False)
        result = simulate(np.full(8, 0.2), topology, DriveConfig(n_virtual=3), feedback=FeedbackParams(True, 0.2, 0.0, 1e-12))
        self.assertFalse(result.diverged)

    def test_single_ring_reaches_analytic_steady_state(self):
        ring = RingParams(detuning_linewidths=0.0)
        topology = TopologyParams(rings=(ring,), coupling_linewidths=(), coupling_phases_rad=(), kerr_enabled=False)
        drive = DriveConfig(n_virtual=1, symbol_time_s=1e-12, power_bias_w=0.05, power_modulation_w=0.0)
        result = simulate(np.full(100, 0.25), topology, drive)
        expected = linear_s21(topology, np.array([0.0]))[0] * np.sqrt(0.05)
        self.assertAlmostEqual(result.through_field[-1, -1].real, expected.real, places=6)
        self.assertAlmostEqual(result.through_field[-1, -1].imag, expected.imag, places=6)

    def test_time_step_refinement_changes_features_below_one_percent(self):
        topology = TopologyParams(kerr_enabled=False)
        drive = DriveConfig(n_virtual=4)
        u = np.linspace(0.0, 0.5, 20)
        coarse = simulate(u, topology, drive, SolverConfig(steps_per_min_lifetime=12.0))
        fine = simulate(u, topology, drive, SolverConfig(steps_per_min_lifetime=24.0))
        relative = np.linalg.norm(coarse.features - fine.features) / np.linalg.norm(fine.features)
        self.assertLess(relative, 0.01)


if __name__ == "__main__":
    unittest.main()
