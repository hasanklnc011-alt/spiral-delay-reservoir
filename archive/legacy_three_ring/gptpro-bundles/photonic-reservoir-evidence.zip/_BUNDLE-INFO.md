﻿# evidence - photonic-reservoir

- Paket amaci: Kanit katmani: run manifest'leri, metrikler, arama sonuclari ve FDTD dogrulama ozetleri. Ham tahmin dizileri BILEREK disarida.
- Export zamani (UTC): 2026-09-02T13:27:34Z
- Git commit: 789f9fa
- Dosya sayisi: 14

Bu bir SNAPSHOT'tir. Canli depo bu tarihten sonra degismis olabilir.
Bulgularini dosya/satir capasiyla ver ki operator canli agacta dogrulayabilsin.
